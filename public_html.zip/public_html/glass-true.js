let subject = document.getElementById('subject-div');
let subjectText = document.getElementById('sub-title');

let errorDiv = document.getElementById('error-div');

let darkBtn = document.getElementById('dark-btn');
let lightBtn = document.getElementById('light-btn');

let outline_chk = document.getElementById('show-outline');

let dark_mode = "hsla(0, 0%, 40%, var(--opacity))";
let light_mode = "hsla(0, 0%, 80%, var(--opacity))";



init();

function init() {
    changeSubjectSize();
    changeSubjectBlur();
    light();
    browserSupport()
}

function browserSupport() {
    var isFirefox = typeof InstallTrigger !== 'undefined';
    var isIE = false || !!document.documentMode;
    if (isFirefox || isIE) {
        errorDiv.style.display = 'block';
    }
}

function changeSubjectSize() {
    let width = document.getElementById('sub-size').value;
    subject.style.width = width + 'px';
}

function changeSubjectRadius() {
    let radius = document.getElementById('sub-radius').value;
    document.documentElement.style.setProperty('--border-radius', radius + 'px');
}

function changeSubjectBlur() {
    let blur = document.getElementById('sub-blur').value;
    document.documentElement.style.setProperty('--blur', blur + 'px');
}


function changeSubjectOpacity() {
    let opacity = document.getElementById('sub-opacity').value;
    document.documentElement.style.setProperty('--opacity', opacity);
}

function dark() {
    subject.classList.remove('glass-light');
    subject.classList.add('glass-dark');
    document.documentElement.style.setProperty('--color1', '#0e0e0e');
    document.documentElement.style.setProperty('--color2', '#1d1d1d');
    darkBtn.classList.add('active');
    lightBtn.classList.remove('active');
    document.documentElement.style.setProperty('--text-color', 'rgb(128, 128, 128, calc(var(--opacity)*4))');
}

function light() {
    subject.classList.remove('glass-dark');
    subject.classList.add('glass-light');
    document.documentElement.style.setProperty('--color1', '#a7cee0');
    document.documentElement.style.setProperty('--color2', '#d0dea7');
    lightBtn.classList.add('active');
    darkBtn.classList.remove('active');
    document.documentElement.style.setProperty('--text-color', 'rgb(255, 255, 255, calc(var(--opacity)*3))');
}


function generateCSS() {
    let styles = getComputedStyle(subject);
    let textStyles = getComputedStyle(subjectText);

    document.getElementById('bg-color').innerText = styles.backgroundColor;
    document.getElementById('box-shadow').innerText = styles.boxShadow;
    document.getElementById('wbox-shadow').innerText = styles.boxShadow;
    document.getElementById('border').innerText = styles.border;
    document.getElementById('border-radius').innerText = styles.borderRadius;
    document.getElementById('wborder-radius').innerText = styles.borderRadius;
    document.getElementById('color').innerText = textStyles.color;
    document.getElementById('backdrop-filter').innerText = styles.backdropFilter;
    document.getElementById('wbackdrop-filter').innerText = styles.backdropFilter;


    var isFirefox = typeof InstallTrigger !== 'undefined';
    if (isFirefox) {
        document.getElementById('border-radius').innerText = styles.borderEndEndRadius;
        document.getElementById('wborder-radius').innerText = styles.borderEndEndRadius;
    }
}

function modalOpen() {
    document.getElementById('modal-div').style.display = "flex";
    generateCSS();
}

function modalClose() {
    document.getElementById('modal-div').style.display = "none";
}

function outline() {
    if (outline_chk.checked) {
        document.documentElement.style.setProperty('--border', '1px');
    } else {
        document.documentElement.style.setProperty('--border', '0px');
    }
}