let subject = document.getElementById('subject-div');
let shadow = 'drop';

let dark = { color: '#1a1a1a', colordark: '#00000080', colorlight: '#3a3a3a60' };
let dark2 = { color: '#1A1B1E', colordark: '#151518', colorlight: '#242529' };
let light = { color: '#e0e5ec', colordark: '#a3b1c680', colorlight: '#ffffff' };
let light2 = { color: '#DEEAF6', colordark: '#BECBD8', colorlight: '#F3F9FF' };
let red = { color: '#d12e2e', colordark: '#b22727', colorlight: '#f03535' };
let blue = { color: '#55b9f3', colordark: '#489dcf', colorlight: '#62d5ff' };
let green = { color: '#2ead5b', colordark: '#27934d', colorlight: '#35c769' };
let yellow = { color: '#eade39', colordark: '#c7bd30', colorlight: '#ffff42' };
let ink = { color: '#2d08b5', colordark: '#220688', colorlight: '#380ae2' };
let purple = { color: '#8d75e6', colordark: '#7863c4', colorlight: '#a287ff' };




init();

function init() {
    changeSubjectSize();
    changeSubjectRadius();
    changeSubjectDistance();
    topLeft();
    drop();
}

function changeSubjectSize() {
    let width = document.getElementById('sub-width').value;
    subject.style.width = width + 'px';
    subject.style.height = width + 'px';
}

function changeSubjectRadius() {
    let radius = document.getElementById('sub-radius').value;
    document.documentElement.style.setProperty('--border-radius', radius + 'px');
}

function changeSubjectDistance() {
    let distance = document.getElementById('sub-distance').value;
    document.documentElement.style.setProperty('--offset', distance + 'px');
}

function drop() {
    shadow = 'drop';
    document.getElementById('drop-btn').classList.add("active");
    document.getElementById('inset-btn').classList.remove("active");
    topLeft();
}

function inset() {
    shadow = 'inset';
    document.getElementById('drop-btn').classList.remove("active");
    document.getElementById('inset-btn').classList.add("active");
    topLeft();
}

function topLeft() {
    subject.className = "";
    if (shadow == 'inset') {
        subject.classList.add("top-left-inset");
    } else {
        subject.classList.add("top-left");
    }
    removeActive("top-left-btn");
}

function topRight() {
    subject.className = "";
    if (shadow == 'inset') {
        subject.classList.add("top-right-inset");
    } else {
        subject.classList.add("top-right");
    }
    removeActive("top-right-btn");
}

function bottomLeft() {
    subject.className = "";
    if (shadow == 'inset') {
        subject.classList.add("bottom-left-inset");
    } else {
        subject.classList.add("bottom-left");
    }
    removeActive("bottom-left-btn");
}

function bottomRight() {
    subject.className = "";
    if (shadow == 'inset') {
        subject.classList.add("bottom-right-inset");
    } else {
        subject.classList.add("bottom-right");
    }
    removeActive("bottom-right-btn");
}

function removeActive(active) {
    var items = document.getElementsByClassName("box");
    Array.from(items).forEach(element => {
        element.classList.remove("active")
    });
    document.getElementById(active).classList.add("active");
}


function color(color) {
    switch (color) {
        case 'light':
            changeColor(light);
            break;
        case 'light2':
            changeColor(light2);
            break;
        case 'dark':
            changeColor(dark);
            break;
        case 'dark2':
            changeColor(dark2);
            break;
        case 'red':
            changeColor(red);
            break;
        case 'green':
            changeColor(green);
            break;

        case 'blue':
            changeColor(blue);
            break;
        case 'yellow':
            changeColor(yellow);
            break;
        case 'ink':
            changeColor(ink);
            break;
        case 'purple':
            changeColor(purple);
            break;
    }
}

function changeColor(theme) {
    document.documentElement.style.setProperty('--color', theme.color);
    document.documentElement.style.setProperty('--color-dark', theme.colordark);
    document.documentElement.style.setProperty('--color-light', theme.colorlight);
}



function generateCSS() {
    let styles = getComputedStyle(subject);
    document.getElementById('bg-color').innerText = styles.backgroundColor;
    document.getElementById('box-shadow').innerText = styles.boxShadow;
    document.getElementById('wbox-shadow').innerText = styles.boxShadow;

    document.getElementById('border-radius').innerText = styles.borderRadius;
    document.getElementById('wborder-radius').innerText = styles.borderRadius;

    document.getElementById('border-radius').innerText = styles.borderRadius;
    document.getElementById('wborder-radius').innerText = styles.borderRadius;

    var isFirefox = typeof InstallTrigger !== 'undefined';
    if (isFirefox) {
        document.getElementById('border-radius').innerText = styles.borderEndEndRadius;
        document.getElementById('wborder-radius').innerText = styles.borderEndEndRadius;
    }
}

function modalOpen() {
    document.getElementById('modal-div').style.display = "flex";
    generateCSS()
}

function modalClose() {
    document.getElementById('modal-div').style.display = "none";
}
